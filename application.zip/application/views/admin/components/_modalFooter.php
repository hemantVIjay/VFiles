         <div class="modal-footer">
            <div class="mt-3">
               <?= $action_button; ?>
               <button type="button" class="btn btn-danger" data-bs-dismiss="modal" aria-label="Close">Cancel</button>
            </div>
         </div>