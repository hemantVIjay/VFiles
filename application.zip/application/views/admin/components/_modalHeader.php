         <div class="modal-header">
            <h5 class="modal-title" id="dyNamicModal"><?php echo$modal_title; ?></h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
         </div>





