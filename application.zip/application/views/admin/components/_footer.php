
</div>
</div>
<!--<script src="<?= base_url(); ?>assets/js/jquery.min.js"></script>-->
<script src="<?= base_url(); ?>assets/js/bootstrap.bundle.min.js"></script>
<script src="<?= base_url(); ?>assets/vendors/toast/jquery.toast.min.js"></script>
</body>
</html>