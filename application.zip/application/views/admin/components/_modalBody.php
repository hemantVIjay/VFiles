<div class="modal-body" style="max-height:400px;overflow-y:auto;">
   <?php echo $modal_content; ?>
</div>