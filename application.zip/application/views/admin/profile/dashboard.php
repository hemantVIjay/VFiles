<?php 
$session_data=$this->session->userdata('login');
?>