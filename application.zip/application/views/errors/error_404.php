<!DOCTYPE html>
<html>
<head>
	<title>403 Forbidden</title>
</head>
<body style="text-align:center;">

<img src="<?= base_url();?>/assets/img/error-404.png" style="width:400px;">

</body>
</html>
