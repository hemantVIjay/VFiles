<section class="abtsec py-5">
	<div class="container">
		<div class="row justify-content-center">
			<div class="col-xl-11">
				<h2 class="pg-title-c">Privacy <span class="text-primary">Policy</span></h2>
				<p class="textc">Get a brief summary of RERA &amp; Its benefits. You can also browse through RERA registered projects in Top cities.</p>
			
			</div>
		</div>
	</div>
</section>
